This is small expansion of mathematics for Python.

math_extended
| - consts.py # Here are some cpmmon constants.
| - functions.py # There are some common functions here, such as generating Fibonacci sequenced.
| - geometry.py # Here is a relatively simple graphic calculation program, but it is not very good.
| - mtypes.py # Here are some new data types, such as fractions and high-precision floating point numbers.

sample program: # Calculate twice high-precision "pi"

from math_extended.mtypes import HighPrecisionFloat
from math_extended.consts import pi

p = HighPrecisionFloat(pi)
result = p * 2
print(result)