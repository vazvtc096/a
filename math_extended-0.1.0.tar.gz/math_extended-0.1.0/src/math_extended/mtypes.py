class fraction:
    def __init__(self, numerator: int|float, denominator: int|float):
        if denominator == 0:
            raise ValueError("denominator cannot be 0")
        self.numerator = float(numerator)
        self.denominator = float(denominator)
    def __str__(self):
        return f"{self.numerator if self.numerator % 1 != 0 else int(self.numerator)}/{self.denominator if self.denominator % 1 != 0 else int(self.denominator)}"
    def __float__(self):
        return self.numerator / self.denominator
    def _tongfen(self, other_denominator: int|float):
        return fraction(self.numerator * other_denominator, self.denominator * other_denominator)
    def montgomery_reduction(self):
        def gcd(a, b):
            while b:
                a, b = b, a % b
            return a
        
        if self.denominator == 0:
            raise ValueError("Denominator cannot be zero")
        
        numerator = self.numerator
        denominator = self.denominator
        
        common_divisor = gcd(abs(numerator), abs(denominator))

        new_num = numerator / common_divisor
        new_den = denominator / common_divisor
        return fraction(new_num, new_den)
    def __add__(self, other):
        if isinstance(other, fraction):
            o_ted = other._tongfen(self.denominator)
            s_ted = self._tongfen(other.denominator)
            result = fraction(o_ted.numerator + s_ted.numerator, o_ted.denominator)
            return result.montgomery_reduction()
        elif isinstance(other, percentage):
            result = self.__add__(other.to_fraction())
            return result.montgomery_reduction()
        elif isinstance(other, int|float):
            result = fraction(self.numerator + (other * self.denominator), self.denominator)
            return result.montgomery_reduction()
        else:
            return NotImplemented
    def __sub__(self, other):
        if isinstance(other, fraction):
            o_ted = other._tongfen(self.denominator)
            s_ted = self._tongfen(other.denominator)
            result = fraction(s_ted.numerator - o_ted.numerator, o_ted.denominator)
            return result.montgomery_reduction()
        elif isinstance(other, percentage):
            result = self.__sub__(other.to_fraction())
            return result.montgomery_reduction()
        elif isinstance(other, int|float):
            result = fraction(self.numerator - (other * self.denominator), self.denominator)
            return result.montgomery_reduction()
        else:
            return NotImplemented
    def __mul__(self, other):
        if isinstance(other, fraction):
            result = fraction(self.numerator * other.numerator, self.denominator * other.denominator)
            return result.montgomery_reduction()
        elif isinstance(other, int|float):
            result = fraction(self.numerator * other, self.denominator)
            return result.montgomery_reduction()
        elif isinstance(other, percentage):
            result = self.__mul__(other.to_fraction())
            return result.montgomery_reduction()
        else:
            return NotImplemented
    def __truediv__(self, other):
        if isinstance(other, fraction):
            result = self.__mul__(other.denominator, other.numerator)
            return result
        elif isinstance(other, int|float):
            result = self.__mul__(fraction(1, other))
            return result
        elif isinstance(other, percentage):
            result = self.__truediv__(other.to_fraction())
            return result.montgomery_reduction()
        else:
            return NotImplemented
    def __lt__(self, other):
        if isinstance(other, fraction|percentage):
            return self.__float__() < other.__float__()
        elif isinstance(other, int|float):
            return self.__float__() < other
        else:
            return NotImplemented
    def __gt__(self, other):
        if isinstance(other, fraction|percentage):
            return self.__float__() > other.__float__()
        elif isinstance(other, int|float):
            return self.__float__() > other
        else:
            return NotImplemented
    def __eq__(self, other):
        if isinstance(other, fraction|percentage):
            return self.__float__() == other.__float__()
        elif isinstance(other, int|float):
            return self.__float__() == other
        else:
            return NotImplemented
    def to_percentage(self):
        n = 100 / self.denominator
        return percentage(self.numerator * n)

class percentage:
    def __init__(self, numerator: int|float):
        self.numerator = float(numerator)
    def __str__(self):
        return f"{self.numerator if self.numerator % 1 != 0 else int(self.numerator)}%"
    def __float__(self):
        return self.numerator / 100
    def __add__(self, other):
        if isinstance(other, percentage):
            result = percentage(self.numerator + other.numerator)
            return result
        elif isinstance(other, int|float):
            result = percentage(self.numerator + other)
            return result
        elif isinstance(other, fraction):
            result = percentage(self.numerator + other.to_percentage().numerator)
            return result
        else:
            return NotImplemented
    def __sub__(self, other):
        if isinstance(other, percentage):
            result = percentage(self.numerator - other.numerator)
            return result
        elif isinstance(other, int|float):
            result = percentage(self.numerator - other)
            return result
        elif isinstance(other, fraction):
            result = percentage(self.numerator - other.to_percentage().numerator)
            return result
        else:
            return NotImplemented
    def to_fraction(self):
        return fraction(self.numerator, 100)

class HighPrecisionFloat:
    def __init__(self, value: float|int|str):
        if isinstance(value, str):
            if value.count('.') != 1:
                raise ValueError("Invalid float format")
            elif value.startswith('.'):
                raise ValueError("Error float format")
            else:
                self.float_bit = len(value.split('.')[1])
                self.value = int(value.replace('.', ''))
        elif isinstance(value, float):
            self.float_bit = len(str(value).split('.')[1])
            self.value = value * (10 ** self.float_bit)
        else:
            self.float_bit = 0
            self.value = value
    def __str__(self):
        value = str(self.value)
        left = value[:-self.float_bit] or '0'
        right = value[-self.float_bit:]
        return f"{left}.{right}"
    def __float__(self):
        return float(self.__str__())
    def __add__(self, other):
        if isinstance(other, HighPrecisionFloat):
            if self.float_bit == other.float_bit:
                value = str(self.value + other.value)
                left = value[:-self.float_bit] or '0'
                right = value[-self.float_bit:]
            elif self.float_bit > other.float_bit:
                comp_bit = self.float_bit - other.float_bit
                o_value = other.value * (10 ** comp_bit)
                value = self.value + o_value
                left = str(value)[:-self.float_bit] or '0'
                right = str(value)[-self.float_bit:]
            elif self.float_bit < other.float_bit:
                comp_bit = other.float_bit - self.float_bit
                s_value = self.value * (10 ** comp_bit)
                value = s_value + other.value
                left = str(value)[:-other.float_bit] or '0'
                right = str(value)[-other.float_bit:]
            return HighPrecisionFloat(f"{left}.{right}")
        elif isinstance(other, int|float):
            o_s = HighPrecisionFloat(other)
            return self.__add__(o_s)
        else:
            return NotImplemented
    def __sub__(self, other):
        if isinstance(other, HighPrecisionFloat):
            if self.float_bit == other.float_bit:
                value = str(self.value - other.value)
                left = value[:-self.float_bit] or '0'
                right = value[-self.float_bit:]
            elif self.float_bit > other.float_bit:
                comp_bit = self.float_bit - other.float_bit
                o_value = other.value * (10 ** comp_bit)
                value = self.value - o_value
                left = str(value)[:-self.float_bit] or '0'
                right = str(value)[-self.float_bit:]
            elif self.float_bit < other.float_bit:
                comp_bit = other.float_bit - self.float_bit
                s_value = self.value * (10 ** comp_bit)
                value = s_value - other.value
                left = str(value)[:-other.float_bit] or '0'
                right = str(value)[-other.float_bit:]
            return HighPrecisionFloat(f"{left}.{right}")
        elif isinstance(other, int|float):
            o_s = HighPrecisionFloat(other)
            return self.__sub__(o_s)
        else:
            return NotImplemented
    def __mul__(self, other):
        if isinstance(other, HighPrecisionFloat):
            add = self.float_bit + other.float_bit
            value = self.value * other.value
            left = str(value)[:-add] or '0'
            right = str(value)[-add:]
            return HighPrecisionFloat(f'{left}.{right}')
        elif isinstance(other, int|float):
            o_s = HighPrecisionFloat(other)
            return self.__mul__(o_s)
        else:
            return NotImplemented
    def __truediv__(self, other):
        if isinstance(other, HighPrecisionFloat):
            if self.float_bit == other.float_bit:
                value = str(self.value / other.value)
                left = (str(value)[:-self.float_bit] or '0').replace('.', '')
                right = str(value)[-self.float_bit:].replace('.', '')
            elif self.float_bit > other.float_bit:
                comp_bit = self.float_bit - other.float_bit
                o_value = other.value * (10 ** comp_bit)
                value = self.value / o_value
                left = (str(value)[:-self.float_bit] or '0').replace('.', '')
                right = str(value)[-self.float_bit:].replace('.', '')
            elif self.float_bit < other.float_bit:
                comp_bit = other.float_bit - self.float_bit
                s_value = self.value * (10 ** comp_bit)
                value = s_value / other.value
                left = (str(value)[:-other.float_bit] or '0').replace('.', '')
                right = str(value)[-other.float_bit:].replace('.', '')
            return HighPrecisionFloat(f"{left}.{right}")
        elif isinstance(other, int|float):
            o_s = HighPrecisionFloat(other)
            return self.__truediv__(o_s)
        else:
            return NotImplemented
    def __round__(self, ndigits: int = 10):
        if ndigits < 0:
            raise ValueError("ndigits must be >= 0")
        v = self.__str__()
        right = v.split('.')[1][:ndigits + 2]
        if int(right[-2]) >= 5:
            right = str(int(right[:-2]) + 1)
            return HighPrecisionFloat(f"{v.split('.')[0]}.{right}")
        else:
            return HighPrecisionFloat(f"{v.split('.')[0]}.{right[:-2]}")