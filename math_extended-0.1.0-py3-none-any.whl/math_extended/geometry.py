from .consts import pi

pi = float(pi)

class circle:
    def __init__(self, radius: float):
        self.radius = radius
        self.diameter = radius * 2
    def __str__(self):
        return "S圆=pi * (r ^ 2)\nC周=pi * d\nV体=S * h=pi * (r ^ 2) * h\nS侧=C * h\nS表=2 * pi * (r * h + r ^ 2)"
    def area(self):
        return pi * self.radius ** 2
    def circumference(self):
        return pi * self.diameter
    def volume(self, height: float):
        return self.area() * height
    def side_aera(self, height: float):
        return self.circumference() * height
    def lateral_area(self, height: float):
        return self.circumference() * height + self.area() * 2

class quadr:
    def __init__(self, side_a: float, side_b: float = None):
        self.side_a = side_a
        self.side_b = side_b if side_b is not None else side_a
    def __str__(self):
        return "S底=a * b\nC=a * 2 + b * 2\nV体=S * h\nS侧=C * h\nS表=C * h + S"
    def area(self):
        return self.side_a * self.side_b
    def circumference(self):
        return self.side_a * 2 + self.side_b * 2
    def volume(self, height: float):
        return self.area() * height
    def lateral_area(self, height: float):
        return self.circumference() * height + self.area() * 2