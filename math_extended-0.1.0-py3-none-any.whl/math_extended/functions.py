def fibonacci(n: int):
    result = [0, 1]
    if n <= 1:
        try:
            return result[:n + 1]
        except IndexError:
            return 0
    else:
        for i in range(2, n + 1):
            result.append(result[i - 1] + result[i - 2])
        return result

def factorial(n: int):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

def gcd(a: int, b: int):
    while b != 0:
        a, b = b, a % b
    return a

def lcm(a: int, b: int):
    return a * b // gcd(a, b)

def cbtd(frac):
    ns = []
    try:
        num = int(frac.montgomery_reduction().denominator)
    except AttributeError:
        if isinstance(frac, int):
            num = frac
        else:
            raise ValueError("frac must be an integer or a fraction")
    for i in range(1, num + 1):
        if num % i == 0:
            ns.append(i)
    return all(n in {1, 2, 5} for n in ns)